package com.hnq40.myapplication1.slot6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot6Adapter extends BaseAdapter {
    private List<Slot6SanPham> list;
    private Context context;

    public Slot6Adapter(List<Slot6SanPham> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Slot6ViewHolder holder;
        if(convertView==null){
            holder=new Slot6ViewHolder();
            convertView=LayoutInflater.from(context)
                    .inflate(R.layout.slot6_item_view,parent,false);
            holder.img=convertView.findViewById(R.id.slot6_itemview_img);
            holder.tvmasp=convertView.findViewById(R.id.slot6_itemview_tvmasp);
            holder.tvtensp=convertView.findViewById(R.id.slot6_itemview_tvtensp);
            holder.tvsl=convertView.findViewById(R.id.slot6_itemview_tvsl);
            holder.btnSua=convertView.findViewById(R.id.slot6_itemview_btnSua);
            holder.btnXoa=convertView.findViewById(R.id.slot6_itemview_btnXoa);
            convertView.setTag(holder);
        }
        else {
            holder = (Slot6ViewHolder) convertView.getTag();
        }
        Slot6SanPham p = list.get(position);
        if(p!=null){
            holder.img.setImageResource(R.drawable.android);
            holder.tvmasp.setText(p.getMasp());
            holder.tvtensp.setText(p.getTensp());
            holder.tvsl.setText(String.valueOf(p.getSl()));
            //xu ly su kien cua button sua
            holder.btnSua.setOnClickListener(v->{
                //bai tap:
                //c1
                //mo dialog va truyen du lieu vao dialog
                //sau khi sua thi dong dialog va tra du lieu ve activity
                //--cach 2:
                //truyen du lieu vao activity con qua intent
            });
            //xu ly su kien cua button xua
            holder.btnXoa.setOnClickListener(v->{
                String masp =list.get(position).getMasp();
                list.remove(position);//xoa trong list
                //xoa trong database
                Slot6SanPhamDAO dao=new Slot6SanPhamDAO(context);

                dao.deleteSP(masp);
                notifyDataSetChanged();//cap nhat trong list
            });
        }

        return convertView;
    }
    static class Slot6ViewHolder{
        ImageView img;
        TextView tvmasp,tvtensp,tvsl;
        Button btnSua,btnXoa;
    }
}
