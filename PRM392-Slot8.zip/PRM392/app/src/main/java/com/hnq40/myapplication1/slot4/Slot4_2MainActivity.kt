package com.hnq40.myapplication1.slot4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.hnq40.myapplication1.R

class Slot4_2MainActivity : AppCompatActivity() {
    private var lv: ListView? = null
    private var adapter: Slot4_1CustomAdapter? = null
    private var ls= ArrayList<Slot4_1Student>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot41_main)
        lv = findViewById(R.id.slot4_1Lv)
        ls.add(Slot4_1Student("An","18",R.drawable.android))
        ls.add(Slot4_1Student("Binh","20",R.drawable.apple))
        ls.add(Slot4_1Student("Chung","22",R.drawable.blogger))
        ls.add(Slot4_1Student("Dung","17",R.drawable.dell))
        adapter=Slot4_1CustomAdapter(ls,this)
        lv!!.adapter=adapter
    }
}