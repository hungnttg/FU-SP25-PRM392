package com.hnq40.myapplication1.slot5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.hnq40.myapplication1.R;
import com.hnq40.myapplication1.slot4.Slot4_1Adapter;

import java.util.ArrayList;
import java.util.List;

public class Slot5_1MainActivity extends AppCompatActivity {
    EditText txtId,txtName,txtPrice;
    Button btnInsert,btnSelect;
    ListView lv;
    Slot5_1Adapter adapter;
    List<Slot5_1Product> ls=new ArrayList<>();
    Context context=this;
    Slot5_1ProductDAO dao;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot51_main);
        txtId = findViewById(R.id.slot5_1_txtId);
        txtName=findViewById(R.id.slot5_1_txtName);
        txtPrice=findViewById(R.id.slot5_1_txtPrice);
        btnInsert = findViewById(R.id.slot5_1BtnInsert);
        btnSelect=findViewById(R.id.slot5_1BtnSelect);
        lv=findViewById(R.id.slot5_1Lv);
        dao = new Slot5_1ProductDAO(context);//tao csdl va bang du lieu
        adapter = new Slot5_1Adapter(context,ls);
        lv.setAdapter(adapter);
        btnInsert.setOnClickListener(v->{
            Slot5_1Product p = new Slot5_1Product();
            p.setId(txtId.getText().toString());
            p.setName(txtName.getText().toString());
            p.setPrice(Double.parseDouble(txtPrice.getText().toString()));
            p.setImage(1);
            if(dao.insertProduct(p)==-1){
                Toast.makeText(context,"Insert that bai",Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(context,"Insert thanh cong",Toast.LENGTH_LONG).show();
            }
        });
        btnSelect.setOnClickListener(v->{
            ls=dao.getAllData();
            adapter = new Slot5_1Adapter(context,ls);
            lv.setAdapter(adapter);
        });

    }
}