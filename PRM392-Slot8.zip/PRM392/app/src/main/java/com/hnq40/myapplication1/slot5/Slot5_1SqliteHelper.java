package com.hnq40.myapplication1.slot5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Slot5_1SqliteHelper extends SQLiteOpenHelper {
    //ham tao csql
    public Slot5_1SqliteHelper(Context context) {
        super(context, "CSDL1", null, 1);
    }
    //ham thuc thi lenh: tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Product (id text PRIMARY KEY,name text,price real,image real);");
    }
    //ham upgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE if exists Product");
    }
}
