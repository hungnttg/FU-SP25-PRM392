package com.hnq40.myapplication1.slot5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot5_1Adapter extends BaseAdapter {
    private Context context;
    private List<Slot5_1Product> ls;

    public Slot5_1Adapter(Context context, List<Slot5_1Product> ls) {
        this.context = context;
        this.ls = ls;
    }

    @Override
    public int getCount() {
        return ls.size();
    }

    @Override
    public Object getItem(int position) {
        return ls.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //thuc hien 2 cong viec
    //tao view (neu chua co view -> tao view moi; neu da co view -> su dung view cu)
    //gan du lieu cho view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. tao view
        Slot5_1ViewHolder holder;
        if(convertView==null){//truong hop chua co view
            //tao view moi
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.slot5_1_itemview,parent,false);
            //anh xa cac thanh phan
            holder = new Slot5_1ViewHolder();
            holder.img=convertView.findViewById(R.id.slot5_1ItemView_img);
            holder.tvId=convertView.findViewById(R.id.slot5_1_ItemView_id);
            holder.tvName=convertView.findViewById(R.id.slot5_1_ItemView_name);
            holder.tvPrice=convertView.findViewById(R.id.slot5_1_ItemView_price);
            //tao 1 template de lan sau su dung
            convertView.setTag(holder);
        }
        else {//neu da co view thi lay view cu ra dung
            holder=(Slot5_1ViewHolder)convertView.getTag();
        }
        //2. gan du lieu cho view
        Slot5_1Product p=ls.get(position);
        holder.img.setImageResource(R.drawable.android);
        holder.tvId.setText(p.getId());
        holder.tvName.setText(p.getName());
        holder.tvPrice.setText(String.valueOf(p.getPrice()));
        return convertView;
    }
    //lop quan ly slot5_1I_itemview.xml
    static class Slot5_1ViewHolder {
        ImageView img;
        TextView tvId,tvName,tvPrice;
    }
}
