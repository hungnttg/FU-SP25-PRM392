package com.hnq40.myapplication1.slot8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.hnq40.myapplication1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Slot8MainActivity extends AppCompatActivity {
    private ListView listView;
    List<ProductSL8> list = new ArrayList<>();
    Slot8Adapter adapter;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot8_main);
        listView=findViewById(R.id.slot8Listview);
        adapter=new Slot8Adapter(list,context);
        listView.setAdapter(adapter);
        //lay du lieu tu server
        new FetchProductTask().execute();
    }
    private class FetchProductTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder response = new StringBuilder();//chua du lieu doc duoc
            try {
                //duong dan doc du lieu
                URL url=new URL("http://10.22.10.72/0api8/api1.php");
                //ket noi
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                //thiet lap phuong thuc doc du lieu
                connection.setRequestMethod("GET");
                //tao buffer doc du lieu
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //doc theo tung dong du lieu
                String line="";//dong de luu du lieu
                while ((line=reader.readLine())!=null){
                    response.append(line);//add line vao response
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();
        }
        //tra ket qua ve cho client
        @Override
        protected void onPostExecute(String result) {
            //xu lý ket qua
            if(result!=null && !result.isEmpty()){//not null va not blank
                try {
                    //lay ve doi tuong JSON
                    JSONObject json = new JSONObject(result);
                    //lay ve mang product
                    JSONArray productsArray=json.getJSONArray("products");
                    //su dung vong lap de doc tung doi tuong con
                    for(int i=0;i<productsArray.length();i++){
                        //lay ve 1 doi tuong con
                        JSONObject prdObject = productsArray.getJSONObject(i);
                        //lay ve cac truong trong doi tuong con
                        String styleid=prdObject.getString("styleid");
                        String brands_filter_facet=prdObject.getString("brands_filter_facet");
                        String price = prdObject.getString("price");
                        String search_image = prdObject.getString("search_image");
                        String product_additional_info=prdObject.getString("product_additional_info");
                        //tao doi tuong moi chua du lieu doc duoc
                        ProductSL8 productSL8=new ProductSL8(search_image,styleid,
                                brands_filter_facet,price,product_additional_info);
                        //them doi tuong vao list
                        list.add(productSL8);
                    }
                    adapter.notifyDataSetChanged();//cap nhat lai adapter
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
            else {
                Toast.makeText(getApplicationContext(),"Loi doc du lieu",Toast.LENGTH_LONG).show();
            }
        }
    }
}