package com.hnq40.myapplication1.slot3

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.hnq40.myapplication1.R

class Slot3_5MainActivity : AppCompatActivity() {
    var lv:ListView?=null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot35_main)
         lv = findViewById<ListView>(R.id.slot3_5Lv)
        getDataToListView()

    }

    private fun getDataToListView() {
        val arr = listOf<String>("a","b","c","d","e")
        val adap = ArrayAdapter(this,android.R.layout.simple_list_item_1,arr)
        lv!!.adapter=adap
    }
}