package com.hnq40.myapplication1.slot2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

public class Slot2_2MainActivity extends AppCompatActivity {
    TextView tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot22_main);
        tv2 = findViewById(R.id.slot2_2Tv2);
        //nhan du lieu tu A chuyen sang
        Intent intent1 = getIntent();
        //giai nen du lieu
        int so1 = intent1.getExtras().getInt("soA");
        int so2 = intent1.getExtras().getInt("soB");
        int tong = so1+so2;
        //hien thi ket qua
        tv2.setText(String.valueOf(tong));
    }
}