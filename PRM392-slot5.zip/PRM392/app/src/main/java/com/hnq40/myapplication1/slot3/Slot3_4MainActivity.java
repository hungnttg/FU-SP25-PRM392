package com.hnq40.myapplication1.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hnq40.myapplication1.R;

public class Slot3_4MainActivity extends AppCompatActivity {
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot34_main);
        listView=findViewById(R.id.slot3_4Listview);
        //datasource
        String[] arr = new String[]{
                "Lap trinh java",
                "Lap trinh C#",
                "Javascript",
                "Python",
                "Lap trinh C++"
        };
        //adapter
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arr);
        //connect adapter to listview
        listView.setAdapter(adapter);
    }
}