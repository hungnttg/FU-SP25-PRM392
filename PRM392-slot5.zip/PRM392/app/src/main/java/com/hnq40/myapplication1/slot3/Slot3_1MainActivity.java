package com.hnq40.myapplication1.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.hnq40.myapplication1.R;

public class Slot3_1MainActivity extends AppCompatActivity {
    //declare controls
    EditText txt1,txt2,txt3;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot31_main);
        //reference id from XML
        txt1 = findViewById(R.id.slot3_1Txt1);
        txt2=findViewById(R.id.slot3_1Txt2);
        txt3 = findViewById(R.id.slot3_1Txt3);
        btn1 = findViewById(R.id.slot3_1Btn1);
        //event
        btn1.setOnClickListener(v->{
            sendData();
        });
    }

    private void sendData() {
        //get data from input control
        int a = Integer.parseInt(txt1.getText().toString());
        int b = Integer.parseInt(txt2.getText().toString());
        int c = Integer.parseInt(txt3.getText().toString());
        //create intent for using
        Intent intent = new Intent(Slot3_1MainActivity.this,Slot3_2MainActivity.class);
        //put data to intent
        intent.putExtra("hsa",a);
        intent.putExtra("hsb",b);
        intent.putExtra("hsc",c);
        //send data
        startActivity(intent);
    }
}