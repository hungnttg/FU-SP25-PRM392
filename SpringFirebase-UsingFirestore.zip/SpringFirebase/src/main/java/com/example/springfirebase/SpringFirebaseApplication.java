package com.example.springfirebase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFirebaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringFirebaseApplication.class, args);
    }
} 