package prm1.fpt.edu.vn;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class MainActivity2 extends AppCompatActivity {
    Button btn1;
    TextView tvKQ;
    Context context = this;
    FirebaseFirestore database;
    String id="";
    ToDo toDo = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tvKQ =findViewById(R.id.slot15TvKQ);
        btn1=findViewById(R.id.slot15_btn1);
        database = FirebaseFirestore.getInstance();//khoi tao database
        btn1.setOnClickListener(v->{
            SelectFireBase();
            //InsertFirebase();
            //UpdateFirebasse();
            //DeleteFirebase();
        });

    }

    private void DeleteFirebase() {
        id="93f9632b-110c-4dcd-a746-d9abf0262fed";
        database.collection("TODO")
                .document(id)
                .delete()//thuc hien xoa
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Delete thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.getMessage());
                    }
                });
    }

    private void UpdateFirebasse() {
        id="93f9632b-110c-4dcd-a746-d9abf0262fed";
        toDo = new ToDo(id,"sua title lan 1","sua content lan 1");
        database.collection("TODO")//ten bang du lieu
                .document(toDo.getId())//lay dong du lieu voi id cho truoc
                .update(toDo.convertHashMap())//thuc hien update
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Update thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.getMessage());
                    }
                });
    }

    private void InsertFirebase() {
        id= UUID.randomUUID().toString();//lay 1 id bat ky
        toDo = new ToDo(id,"title 1","content 1");
        HashMap<String,Object> mapTodo = toDo.convertHashMap();
        database.collection("TODO").document(id)
                .set(mapTodo)//insert
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Insrt firebase thanhf cong");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.getMessage());
                    }
                });
    }
    String strKQ="";
    private ArrayList<ToDo> SelectFireBase() {
        strKQ="";
        ArrayList<ToDo> ls = new ArrayList<>();
        database.collection("TODO")
                .get()//select data
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){//neu da doc thanh conh
                            strKQ="";
                            for (QueryDocumentSnapshot documentSnapshot:task.getResult()){
                                ToDo toDo1 = documentSnapshot.toObject(ToDo.class);
                                strKQ += "Id: "+toDo1.getId()+"; Title: "+toDo1.getTitle()+"\n";
                                ls.add(toDo1);
                            }
                            tvKQ.setText(strKQ);
                        }
                    }
                });
        return ls;
    }
}