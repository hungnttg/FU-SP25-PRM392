package prm1.fpt.edu.vn;

import java.io.Serializable;
import java.util.HashMap;

public class ToDo implements Serializable {
    private String id,title,content;

    public ToDo() {
    }

    public ToDo(String id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }
    //ham xu ly du lieu thao tac voi DB
    public HashMap<String, Object> convertHashMap(){
        HashMap<String, Object> w = new HashMap<>();
        w.put("id",id);
        w.put("title",title);
        w.put("content",content);
        return w;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
