package com.hnq40.myapplication1.slot1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

public class Slot11MainActivity extends AppCompatActivity {
    //khai bao cac control
    TextView tv1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot11_main);
        //anh xa cac control
        tv1=findViewById(R.id.slot1Tv1);
        btn1=findViewById(R.id.sot1Btn1);
        //xu ly su kien click button
        btn1.setOnClickListener(v ->{
            //doi text cua textview
            tv1.setText("Ban vua click vao button");
        });
    }
}