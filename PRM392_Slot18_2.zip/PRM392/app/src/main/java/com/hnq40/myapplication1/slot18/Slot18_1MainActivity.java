package com.hnq40.myapplication1.slot18;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

import java.util.Calendar;

public class Slot18_1MainActivity extends AppCompatActivity {
    Button btnDate,btnTime,btnAlert;
    TextView tvDate,tvTime;
    Context context = this;
    Calendar calendar=Calendar.getInstance();
    final int gio = calendar.get(Calendar.HOUR_OF_DAY);
    final int phut = calendar.get(Calendar.MINUTE);
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot181_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnDate = findViewById(R.id.slot18_1BtnDate);
        btnTime = findViewById(R.id.slot18_1BtnTime);
        btnAlert = findViewById(R.id.slot18_1BtnAlert);
        tvDate = findViewById(R.id.slot18_1TvDate);
        tvTime = findViewById(R.id.slot18_1TvTime);
        btnTime.setOnClickListener(v->{
            //b1. tao time picker
            TimePickerDialog tp = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    tvTime.setText(hourOfDay+ " : "+minute);
                }
            },gio,phut,android.text.format.DateFormat.is24HourFormat(context));
            //b2. hien thi
            tp.show();
        });
        btnDate.setOnClickListener(v->{
            Calendar c = Calendar.getInstance();
            int day = c.get(Calendar.DAY_OF_MONTH);
            int month = c.get(Calendar.MONTH);
            int year = c.get(Calendar.YEAR);
            //b1. tao dialog
            DatePickerDialog dp = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year1, int month1, int dayOfMonth) {
                    month1+=1;
                    tvDate.setText(dayOfMonth+"/"+month1+"/"+year);
                }
            },day,month,year);
            dp.show();
        });
        btnAlert.setOnClickListener(v->{
            alertDialogFn();
        });
    }
    public void alertDialogFn(){
        //b1. Tao builder
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        //b2. them cac thanh phan cho builder
        builder.setTitle("Thong bao");
        builder.setMessage("Ban co 1 thonhg bao");
        //them btn ok
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Ban chonj OK",Toast.LENGTH_LONG).show();
            }
        });
        //them btn cancel
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Ban chonj Cancel",Toast.LENGTH_LONG).show();
            }
        });
        //b3 - tao dialog
        AlertDialog alertDialog = builder.create();
        //b4 - hien thi
        alertDialog.show();
    }
}