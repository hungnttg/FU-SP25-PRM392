package com.hnq40.myapplication1.slot8;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class ProductSL8 implements Parcelable {
    private String search_image;
    private String styleid;
    private String brands_filter_facet;
    private String price;
    private String product_additional_info;

    public ProductSL8() {
    }

    public ProductSL8(String search_image, String styleid, String brands_filter_facet, String price, String product_additional_info) {
        this.search_image = search_image;
        this.styleid = styleid;
        this.brands_filter_facet = brands_filter_facet;
        this.price = price;
        this.product_additional_info = product_additional_info;
    }

    public ProductSL8(String search_image, String styleid, String brands_filter_facet, String price) {
        this.search_image = search_image;
        this.styleid = styleid;
        this.brands_filter_facet = brands_filter_facet;
        this.price = price;
    }

    protected ProductSL8(Parcel in) {
        search_image = in.readString();
        styleid = in.readString();
        brands_filter_facet = in.readString();
        price = in.readString();
        product_additional_info = in.readString();
    }

    public static final Creator<ProductSL8> CREATOR = new Creator<ProductSL8>() {
        @Override
        public ProductSL8 createFromParcel(Parcel in) {
            return new ProductSL8(in);
        }

        @Override
        public ProductSL8[] newArray(int size) {
            return new ProductSL8[size];
        }
    };

    public String getSearch_image() {
        return search_image;
    }

    public void setSearch_image(String search_image) {
        this.search_image = search_image;
    }

    public String getStyleid() {
        return styleid;
    }

    public void setStyleid(String styleid) {
        this.styleid = styleid;
    }

    public String getBrands_filter_facet() {
        return brands_filter_facet;
    }

    public void setBrands_filter_facet(String brands_filter_facet) {
        this.brands_filter_facet = brands_filter_facet;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getProduct_additional_info() {
        return product_additional_info;
    }

    public void setProduct_additional_info(String product_additional_info) {
        this.product_additional_info = product_additional_info;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(search_image);
        parcel.writeString(styleid);
        parcel.writeString(brands_filter_facet);
        parcel.writeString(price);
        parcel.writeString(product_additional_info);
    }
}
