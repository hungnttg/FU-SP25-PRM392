package com.hnq40.myapplication1.slot4

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.hnq40.myapplication1.R

class Slot4_3Adapter(val list:List<Slot4_3Student>,val context: Context): BaseAdapter() {
    override fun getCount(): Int {
        return list.size
    }

    override fun getItem(position: Int): Any {
        return  list[position]
    }

    override fun getItemId(position: Int): Long {
        return  position.toLong()
    }

    override fun getView(position: Int, convertview: View?, parent: ViewGroup?): View? {
        var viewHolder: Slot4_3ViewHolder
        var convertview = convertview
        if(convertview==null){
            convertview = LayoutInflater.from(context).inflate(R.layout.slot4_1_itemview,null)
            viewHolder = Slot4_3ViewHolder()
            viewHolder.img=convertview!!.findViewById(R.id.slot4_1_itemview_img)
            viewHolder.tvName=convertview!!.findViewById(R.id.slot4_1_itemview_tvName)
            viewHolder.tvAge=convertview!!.findViewById(R.id.slot4_1_itemview_tvAge)
            convertview.tag=viewHolder
        }
        else {
            viewHolder = convertview.tag as Slot4_3ViewHolder
        }
        viewHolder.img!!.setImageResource(list[position].pic)
        viewHolder.tvName!!.text=list[position].name
        viewHolder.tvAge!!.text=list[position].age
        return  convertview;
    }
     internal class Slot4_3ViewHolder{
         var img: ImageView?=null
         var tvName: TextView?=null
         var tvAge: TextView?=null
     }
}