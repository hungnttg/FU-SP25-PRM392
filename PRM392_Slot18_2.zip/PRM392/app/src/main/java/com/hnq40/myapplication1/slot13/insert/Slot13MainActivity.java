package com.hnq40.myapplication1.slot13.insert;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot13MainActivity extends AppCompatActivity {
    Button btnInsert,btnSelect,btnUpdate,btnDelete;
    TextView tvKQ;
    EditText txtId,txtName,txtPrice,txtDes;
    String strKQ="";
    List<Prd> ls;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot13_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnInsert =findViewById(R.id.slot13_btnInsert);
        btnSelect=findViewById(R.id.slot13_btnSelect);
        btnUpdate=findViewById(R.id.slot13_btnUpdate);
        btnDelete=findViewById(R.id.slot13_btnDelete);
        txtId=findViewById(R.id.slot13_txtId);
        txtName=findViewById(R.id.slot13_txtName);
        txtPrice = findViewById(R.id.slot13_txtPrice);
        txtDes=findViewById(R.id.slot13_txtDes);
        btnSelect.setOnClickListener(v->{
            selectData();
        });
        btnInsert.setOnClickListener(v->{
            insertData();
        });
        tvKQ=findViewById(R.id.slot13_tvKQ);
        btnUpdate.setOnClickListener(v->{
            updateData();
        });
        btnDelete.setOnClickListener(v->{
            deleteData();
        });
    }
    public void deleteData(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Call<SvrResponsePrd> call = interfaceInsertPrd.deletePrd(txtId.getText().toString());
        call.enqueue(new Callback<SvrResponsePrd>() {
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd = response.body();
                tvKQ.setText(svrResponsePrd.getMessage());
            }

            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }
    public void updateData(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Call<SvrResponsePrd> call = interfaceInsertPrd.updatePrd(txtId.getText().toString(),
                txtName.getText().toString(),txtPrice.getText().toString(),
                txtDes.getText().toString());
        call.enqueue(new Callback<SvrResponsePrd>() {
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd = response.body();
                tvKQ.setText(svrResponsePrd.getMessage());
            }

            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }
    public void selectData(){
        strKQ="";
        //1. Tao doi tuong Retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi ham select trong interface
        //2.1. tao doi tuong
        InterfaceSelectPrd interfaceSelectPrd
                =retrofit.create(InterfaceSelectPrd.class);
        //2.2 chuan bi ham
        Call<SvrResponseSelect> call=interfaceSelectPrd.getPrd();
        //2.3. thuc thi request
        call.enqueue(new Callback<SvrResponseSelect>() {
            @Override
            public void onResponse(Call<SvrResponseSelect> call, Response<SvrResponseSelect> response) {
                //thanh cong
                SvrResponseSelect responseSelect=response.body();//lay ket qua tra ve
                ls=new ArrayList<>(Arrays.asList(responseSelect.getProducts()));//chuyen sang List
                //for ket qua
                for(Prd p: ls){
                    strKQ += "Id: "+p.getId()+"; Name: "+p.getName()+"; Price: "+p.getPrice()
                            +"; Des: "+p.getDescription()+"\n";
                }
                tvKQ.setText(strKQ);
            }

            @Override
            public void onFailure(Call<SvrResponseSelect> call, Throwable t) {
                //that bai
                tvKQ.setText(t.getMessage());
            }
        });
    }
    public void insertData(){
        //1. Tao doi tuong chua du lieu
        Prd prd=new Prd();
        //2. Dua du lieu nhap vao doi tuong
        prd.setId(txtId.getText().toString());
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //3. tao doi tuong retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //4. goi ham insert trong interface
        //4.1 tao doi tuong
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        //4.2 chuan bi ham
        Call<SvrResponsePrd> call=interfaceInsertPrd.insertPrd(prd.getId(),prd.getName(),prd.getPrice(),
                prd.getDescription());
        //4.3. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                //thanh cong
                SvrResponsePrd svrResponsePrd = response.body();
                tvKQ.setText(svrResponsePrd.getMessage());
            }

            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                //that bai
                tvKQ.setText(t.getMessage());
            }
        });
    }
}