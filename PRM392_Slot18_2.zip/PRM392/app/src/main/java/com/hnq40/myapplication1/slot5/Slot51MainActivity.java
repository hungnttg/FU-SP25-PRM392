package com.hnq40.myapplication1.slot5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot51MainActivity extends AppCompatActivity {
    Button btnI,btnS;
    ListView lv;
    Context context=this;
    Slot51Adapter adapter;
    EditText txtId,txtName,txtPrice;
    List<Slot5Product> list = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot51_main);
        btnI=findViewById(R.id.slot51BtnI);
        btnS=findViewById(R.id.slot51BtnS);
        txtId=findViewById(R.id.slot5_1_txtID);
        txtName=findViewById(R.id.slot5_1_txtName);
        txtPrice=findViewById(R.id.slot5_1_txtPrice);
        lv=findViewById(R.id.slot51Lv);
        Slot51DAO dao = new Slot51DAO(context);//truc tiep tao db va bang du lieu
        list=dao.getAllData();
        adapter=new Slot51Adapter(this,list);
        lv.setAdapter(adapter);
        btnI.setOnClickListener(v->{
            Slot5Product p=new Slot5Product();
            p.setId(txtId.getText().toString());
            p.setName(txtName.getText().toString());
            p.setPrice(Double.parseDouble(txtPrice.getText().toString()));
            int kq=dao.insertProd(p);
            if(kq<0){
                Toast.makeText(getApplicationContext(),"Insert that bai",Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(getApplicationContext(),"Insert thanh cong",Toast.LENGTH_LONG).show();
            }
        });
        btnS.setOnClickListener(v->{
            list=dao.getAllData();
            adapter=new Slot51Adapter(this,list);
            lv.setAdapter(adapter);
        });
    }
}