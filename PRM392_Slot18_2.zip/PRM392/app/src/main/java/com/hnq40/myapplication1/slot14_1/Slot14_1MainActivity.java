package com.hnq40.myapplication1.slot14_1;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

public class Slot14_1MainActivity extends AppCompatActivity {
    EditText txtId,txtName,txtPrice,txtDes;
    Button btnInsert, btnSelect,btnUpdate, btnDelete;
    TextView tvKQ;
    String strKQ="";
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot13_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txtId=findViewById(R.id.slot13_txtId);
        txtName=findViewById(R.id.slot13_txtName);
        txtPrice=findViewById(R.id.slot13_txtPrice);
        txtDes = findViewById(R.id.slot13_txtDes);
        btnInsert=findViewById(R.id.slot13_btnInsert);
        btnSelect=findViewById(R.id.slot13_btnSelect);
        btnUpdate = findViewById(R.id.slot13_btnUpdate);
        btnDelete = findViewById(R.id.slot13_btnDelete);
        tvKQ = findViewById(R.id.slot13_tvKQ);
        btnSelect.setOnClickListener(v->{
            FunctionVolley1 functionVolley1=new FunctionVolley1();
            //functionVolley1.readHtmlByStringRequest(context,tvKQ);
            //functionVolley1.read_json_Array_of_objects(context,tvKQ);
            functionVolley1.deleteVolley(context,tvKQ,txtId.getText().toString());
        });
    }
}