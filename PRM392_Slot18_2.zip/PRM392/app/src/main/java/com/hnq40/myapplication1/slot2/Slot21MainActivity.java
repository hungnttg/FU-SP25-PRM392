package com.hnq40.myapplication1.slot2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

public class Slot21MainActivity extends AppCompatActivity {
    EditText txt1,txt2;
    TextView tv1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot21_main);
        //anh xa cac ID
        txt1 = findViewById(R.id.slot2_1_txt1);
        txt2 = findViewById(R.id.slot2_1_txt2);
        btn1 = findViewById(R.id.slot2_1_btn1);
        tv1 = findViewById(R.id.slot2_1_tv1);
        //xu ly su kien
        btn1.setOnClickListener(v->{
//            //lay du lieu nguoi dung nhap va chuyen sang so
//            int a = Integer.parseInt(txt1.getText().toString());
//            int b = Integer.parseInt(txt2.getText().toString());
//            int tong = a+b; //tinh tong
//            tv1.setText(String.valueOf(tong));
            //1.tao intent
            Intent intent = new Intent(Slot21MainActivity.this,Slot2_2MainActivity.class);
            //2.dua du lieu vao intent
            intent.putExtra("chuoi1",txt1.getText().toString());
            intent.putExtra("chuoi2",txt2.getText().toString());
            //thuc hien chuyen du lieu qua intent
            startActivity(intent);

        });
    }
}