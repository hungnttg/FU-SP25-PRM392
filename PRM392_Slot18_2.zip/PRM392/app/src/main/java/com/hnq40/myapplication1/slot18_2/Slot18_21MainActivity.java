package com.hnq40.myapplication1.slot18_2;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

import java.util.Calendar;

public class Slot18_21MainActivity extends AppCompatActivity {
    Button btnDate, btnTime,btnOKCancel,btnRadio,btnCheckbox,btnLogin;
    TextView tvKQ;
    Context context = this;
    Calendar calendar = Calendar.getInstance();
    int year1 = calendar.get(Calendar.YEAR);
    int month1 = calendar.get(Calendar.MONTH);
    int day1 = calendar.get(Calendar.DAY_OF_MONTH);
    int hour1 = calendar.get(Calendar.HOUR_OF_DAY);
    int minute1 = calendar.get(Calendar.MINUTE);
    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot1821_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnDate  =findViewById(R.id.Slot18_21BtnDate);
        btnTime = findViewById(R.id.slot18_21BtnTime);
        tvKQ = findViewById(R.id.slot18_21TvKQ);
        btnTime.setOnClickListener(v->{
            //B1. tao time picker
            TimePickerDialog timePickerDialog = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    //b2 - xu ly su kien
                    tvKQ.setText(hourOfDay+" : "+minute);
                }
            },hour1,minute1,android.text.format.DateFormat.is24HourFormat(context));
            //b3 - hien thi
            timePickerDialog.show();
        });
        btnDate.setOnClickListener(v->{
            //b1. tao date picker
            DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                   //b2: xu ly su kien
                     month++;
                    tvKQ.setText(dayOfMonth+"/"+month+"/"+year);
                }
            },year1,month1,day1);
            //b3 - hien thi
            datePickerDialog.show();
        });
        btnOKCancel = findViewById(R.id.slot18_21BtnOKCancel);
        btnOKCancel.setOnClickListener(v->{
            //b1. tao builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            //b2. them cac thanh phan cho builder
            builder.setTitle("Yeu cau confirm");
            builder.setMessage("Ban co chac khong?");
            //button ok
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),"Ban da dong y",Toast.LENGTH_LONG).show();
                }
            });
            //button cancel
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),"Ban khong dong y",Toast.LENGTH_LONG).show();
                }
            });
            //b3 - tao dialog
            AlertDialog alertDialog = builder.create();
            //b4-hien thi dialog
            alertDialog.show();
        });

        btnRadio = findViewById(R.id.slot18_21BtnRadio);
        btnRadio.setOnClickListener(v->{
            //tao mang
            final String[] arr = new String[]{"Nam","Nu"};
            //tao builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            //tao cac thanh phan cho builder
            builder.setTitle("Chon gioi tinh");
            builder.setSingleChoiceItems(arr, 0, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),"Ban chon: "+arr[which].toString(),Toast.LENGTH_LONG).show();
                }
            });
            //tao dialog
            AlertDialog alertDialog = builder.create();
            //hien thi
            alertDialog.show();
        });
        btnCheckbox = findViewById(R.id.slot18_21BtnCheck);
        btnCheckbox.setOnClickListener(v->{
            //B1 - tao mang
            final String[] arr = new String[]{"An","Choi","Hoc","Lam"};
            //B2 - tao builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            //tao cac thanh phan cho builder
            builder.setTitle("Chon so thich");
            builder.setMultiChoiceItems(arr, null, new DialogInterface.OnMultiChoiceClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                    Toast.makeText(getApplicationContext(),"Ban cbon: "+arr[which].toString(),Toast.LENGTH_SHORT).show();
                }
            });
            //b3 - tao dialog
            AlertDialog alertDialog = builder.create();
            //b4 - hien thi dialog
            alertDialog.show();
        });
        //----
        btnLogin = findViewById(R.id.slot18_21BtnLogin);
        btnLogin.setOnClickListener(v->{
            //b1- tao builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            //b2- gan layout
            LayoutInflater inflater = getLayoutInflater();
            View view1 = inflater.inflate(R.layout.slot18_item_view,null );
            builder.setView(view1);//set view cho builder
            //anh xa cac thanh phan
            final  EditText txtUser = view1.findViewById(R.id.slot18_21_item_txtUsername);
            final EditText txtPass = view1.findViewById(R.id.slot18_21_item_txtPassword);
            //them cac thanh phan
            builder.setTitle("Login form");//them title
            //them login button
            builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),"Xin chao, "+txtUser.getText().toString(),
                            Toast.LENGTH_LONG).show();
                }
            });
            //them button cancel
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),"Ban chon Canel",Toast.LENGTH_LONG).show();
                }
            });
            //b3- tao dialog
            AlertDialog alertDialog = builder.create();
            //b4- hien thi
            alertDialog.show();
        });
    }
}