package com.hnq40.myapplication1.slot14;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

public class Slot14_1MainActivity extends AppCompatActivity {
    Button btnSelect;
    TextView tvKQ;
    EditText txtId,txtName,txtPrice,txtDes;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot13_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnSelect=findViewById(R.id.slot13_btnSelect);
        tvKQ=findViewById(R.id.slot13_tvKQ);
        txtId=findViewById(R.id.slot13_txtId);
        txtName=findViewById(R.id.slot13_txtName);
        txtPrice=findViewById(R.id.slot13_txtPrice);
        txtDes = findViewById(R.id.slot13_txtDes);
        btnSelect.setOnClickListener(v->{
            FnVolley1 fnVolley1 = new FnVolley1();
            //fnVolley1.getStringVolley(context,tvKQ);
            //fnVolley1.getJSON_Array_of_Objects(context,tvKQ);
            //fnVolley1.deleteVolley(context,tvKQ);
            fnVolley1.updateVolley(context,tvKQ,txtId.getText().toString(),txtName.getText().toString(),
                    txtPrice.getText().toString(),txtDes.getText().toString());
        });
    }
}