package com.hnq40.myapplication1.slot13.insert;

import retrofit2.Call;
import retrofit2.http.GET;

public interface InterfaceSelectPrd {
    @GET("select_prd.php")
    Call<SvrResponseSelect> getPrd();
}
