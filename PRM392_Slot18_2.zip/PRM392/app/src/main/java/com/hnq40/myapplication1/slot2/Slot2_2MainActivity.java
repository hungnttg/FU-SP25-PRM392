package com.hnq40.myapplication1.slot2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

public class Slot2_2MainActivity extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot22_main);
        tv1=findViewById(R.id.slot2_2_tv1);
        //don du lieu chuyen tu A sang
        Intent intent1 = getIntent();
        //boc tach du lieu
        String chuoi1 = intent1.getExtras().getString("chuoi1");
        String chuoi2 = intent1.getExtras().getString("chuoi2");
        int a = Integer.parseInt(chuoi1);
        int b = Integer.parseInt(chuoi2);
        int tong = a + b;
        tv1.setText(String.valueOf(tong));
    }
}