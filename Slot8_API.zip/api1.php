<?php
//trước tên biến luôn có dấu $, ví dụ $a
//truy cập thuộc tính của đối tượng, dùng dấu ->
//nối chuỗi: dùng dấu chấm (.)
//in ra màn hình: echo
//còn lại: gần giống với java
//---------------
header('Access-Control-Allow-Origin: *');//cho phép truy cập full control
$host="localhost";$u="root";$p="";$db="a8";//khai bao thong tin server
$conn = new mysqli($host,$u,$p,$db);//ket noi voi csdl
$result = $conn->query("select * from mytable");//truy van csdl
while($row[]=$result->fetch_assoc()){//doc ket qua
    $json = json_encode($row);//chuyen sang json
}
echo '{"products":'.$json.'}';//them ten bang du lieu (products) va in ra ket qua
$conn->close();//dong ket noi