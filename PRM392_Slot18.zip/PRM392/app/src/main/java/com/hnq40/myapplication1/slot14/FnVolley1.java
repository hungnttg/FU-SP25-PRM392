package com.hnq40.myapplication1.slot14;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class FnVolley1 {
    //doc du lieu tu trang google.com
    public void getStringVolley(Context context, TextView textView){
        //1. tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. url:
        String url="https://www.google.com/";
        //3. truyen tham so
        StringRequest stringRequest = new StringRequest(
                Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("KQ: "+response.substring(0,1000));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        }
        );
        //4. thuc thi request
        queue.add(stringRequest);
    }
    String strKQ="";
    public void getJSON_Array_of_Objects(Context context,TextView textView){
        strKQ="";
        //1. tao request
        RequestQueue queue=Volley.newRequestQueue(context);
        //2. url:
        String url="https://hungnttg.github.io/array_json_new.json";
        //3. truyen tham so
        JsonArrayRequest request = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for(int i=0;i<response.length();i++){
                    try {
                        JSONObject person = response.getJSONObject(i);
                        String id=person.getString("id");
                        String name=person.getString("name");
                        String email = person.getString("email");
                        strKQ += "Id: "+ id+"\n";
                        strKQ += "Name: "+ name+"\n";
                        strKQ += "Email: "+ email+"\n";
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                textView.setText(strKQ);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //4. thuc thi request
        queue.add(request);
    }
    //---
    public void deleteVolley(Context context,TextView textView){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "http://10.22.10.72/0api6/delete_prd.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("Delete thanh cong");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
               textView.setText(error.getMessage());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> m = new HashMap<>();
                m.put("id","3");
                return m;
            }
        };
        queue.add(request);
    }
    public void insertVolley(Context context,TextView textView,String id,String name,String price,String description){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "http://10.22.10.72/0api6/insert_prd.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("Insert thanh cong");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> m = new HashMap<>();
                m.put("id",id);
                m.put("name",name);
                m.put("price",price);
                m.put("description",description);
                return m;
            }
        };
        queue.add(request);
    }
    public void updateVolley(Context context,TextView textView,String id,String name,String price,String description){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "http://10.22.10.72/0api6/update_prd.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("Update thanh cong");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> m = new HashMap<>();
                m.put("id",id);
                m.put("name",name);
                m.put("price",price);
                m.put("description",description);
                return m;
            }
        };
        queue.add(request);
    }
}
