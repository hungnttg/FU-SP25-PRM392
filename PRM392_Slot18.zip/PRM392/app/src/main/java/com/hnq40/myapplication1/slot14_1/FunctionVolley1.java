package com.hnq40.myapplication1.slot14_1;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class FunctionVolley1 {
    public void readHtmlByStringRequest(Context context, TextView textView){
        RequestQueue requestQueue= Volley.newRequestQueue(context);
        String url = "https://www.google.com/";
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String strKQ = response.substring(0,1000);
                textView.setText(strKQ);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        requestQueue.add(request);
    }
    String strKQ="";
    public void read_json_Array_of_objects(Context context,TextView textView){
        strKQ ="";
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "https://hungnttg.github.io/array_json_new.json";
        //Mang cua cac doi tuong => JsonArrayRequest
        JsonArrayRequest request = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for(int i=0;i<response.length();i++){
                    //object => JSONObject
                    try {
                        JSONObject person = response.getJSONObject(i);
                        String id = person.getString("id");
                        String name = person.getString("name");
                        String email = person.getString("email");
                        strKQ+= "Id: "+id+"; Name: "+name+"; Email: "+email+"\n";
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                textView.setText(strKQ);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        queue.add(request);
    }
    public void insertVolley(Context context,TextView tvKQ,String id,String name,String price, String des){
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest request = new StringRequest(Request.Method.POST, "http://10.22.10.72/0api6/insert_prd.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        tvKQ.setText("insert thanh cong");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKQ.setText(error.getMessage());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> m = new HashMap<>();
                m.put("id",id);
                m.put("name",name);
                m.put("price",price);
                m.put("description",des);
                return m;
            }
        };
        queue.add(request);
    }
    public void updateVolley(Context context,TextView tvKQ,String id,String name,String price, String des){
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest request = new StringRequest(Request.Method.POST, "http://10.22.10.72/0api6/update_prd.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        tvKQ.setText("insert thanh cong");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKQ.setText(error.getMessage());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> m = new HashMap<>();
                m.put("id",id);
                m.put("name",name);
                m.put("price",price);
                m.put("description",des);
                return m;
            }
        };
        queue.add(request);
    }
    public void deleteVolley(Context context,TextView tvKQ,String id){
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest request = new StringRequest(Request.Method.POST, "http://10.22.10.72/0api6/delete_prd.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        tvKQ.setText("delete thanh cong");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKQ.setText(error.getMessage());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> m = new HashMap<>();
                m.put("id",id);
                return m;
            }
        };
        queue.add(request);
    }
}
