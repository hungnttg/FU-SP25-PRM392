package com.hnq40.myapplication1.slot13_1;

public class ResponseSelectPrd {//GET
    private Prod[] products;
    private String message;

    public Prod[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
