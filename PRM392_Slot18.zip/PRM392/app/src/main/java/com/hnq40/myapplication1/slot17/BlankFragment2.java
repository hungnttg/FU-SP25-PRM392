package com.hnq40.myapplication1.slot17;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.hnq40.myapplication1.R;


public class BlankFragment2 extends Fragment {

    Button btn2;
    EditText txt2;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_blank2, container, false);
        //anh xa
        btn2 = view.findViewById(R.id.slot17Fr2Btn2);
        txt2 = view.findViewById(R.id.slot17Fr2Txt2);
        //xu ly su kien
        btn2.setOnClickListener(v->{

        });
        return view;
    }
}