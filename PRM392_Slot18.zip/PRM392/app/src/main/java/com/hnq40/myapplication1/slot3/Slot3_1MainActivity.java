package com.hnq40.myapplication1.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.hnq40.myapplication1.R;

public class Slot3_1MainActivity extends AppCompatActivity {
    //khai bao cac control
    EditText txt1,txt2,txt3;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot31_main);
        //anh xa cac control
        txt1 = findViewById(R.id.slot3_1Txt1);
        txt2 = findViewById(R.id.slot3_1Txt2);
        txt3=findViewById(R.id.slot3_1Txt3);
        btn1 = findViewById(R.id.slot3_1Btn1);
        //xu ly su kien
        btn1.setOnClickListener(v->{
            sendData();
        });
    }

    private void sendData() {
        //get data from input of user
        String strA = txt1.getText().toString();
        String strB = txt2.getText().toString();
        String strC = txt3.getText().toString();
        //create intent
        Intent intent = new Intent(Slot3_1MainActivity.this,Slot3_2MainActivity.class);
        //put data to intent
        intent.putExtra("hsa",strA);
        intent.putExtra("hsb",strB);
        intent.putExtra("hsc",strC);
        //start Activity
        startActivity(intent);
    }
}