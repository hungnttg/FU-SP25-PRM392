package com.hnq40.myapplication1.slot8;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot9CartActivity extends AppCompatActivity {
    Slot8Adapter adapter;
    Context context=this;
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot9_cart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot9_cart_listview);
        //init cart
        Slot9CartManager cartManager = Slot9CartManager.getInstance();
        //init cartItems
        List<ProductSL8> cartItems = cartManager.getCartItems();
        adapter=new Slot8Adapter(cartItems,context);
        listView.setAdapter(adapter);
    }
}