package com.hnq40.myapplication1.slot17;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.hnq40.myapplication1.R;

public class Slot17_2MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot172_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        viewPager = findViewById(R.id.slot17_1ViewPage);
        tabLayout = findViewById(R.id.slot17_1TabLayout);
        addTabLayout(viewPager);
        tabLayout.setupWithViewPager(viewPager);
    }
    //dinh nghia ham addTabLayout
    public void addTabLayout(ViewPager viewPager){
        //tao adapter
        Slot17_1Adapter adapter = new Slot17_1Adapter(getSupportFragmentManager());
        //them fragment vao Adapter
        adapter.addFrag(new BlankFragment1(),"ONE");
        adapter.addFrag(new BlankFragment2(),"TWO");
        adapter.addFrag(new BlankFragment3(),"THREE");
        //dua adapter vao viewPager
        viewPager.setAdapter(adapter);
    }
}