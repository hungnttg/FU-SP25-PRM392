package com.hnq40.myapplication1.slot8;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;
import com.squareup.picasso.Picasso;

public class Slot9DetailActivity1 extends AppCompatActivity {
    ImageView imageView;
    Button btnAddToCart;
    ProductSL8 productSL8=null;
    TextView tvstyleid,tvbrands_filter_facet,tvprice,tvproduct_additional_info,tvsl;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot9_detail1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //init cart
        Slot9CartManager cartManager = Slot9CartManager.getInstance();
        btnAddToCart = findViewById(R.id.slot9_detail_btnAddToCart);
        btnAddToCart.setOnClickListener(v->{
            Intent intent1 = new Intent(this,Slot9CartActivity.class);
            cartManager.addProductToCart(productSL8);
            this.startActivity(intent1);
        });
        imageView= findViewById(R.id.slot9_detail_img);
        tvstyleid=findViewById(R.id.slot9_detail_tvstyleid);
        tvbrands_filter_facet=findViewById(R.id.slot9_detail_tvbrands_filter_facet);
        tvprice = findViewById(R.id.slot9_detail_tvprice);
        tvproduct_additional_info=findViewById(R.id.slot9_detail_tvproduct_additional_info);
        tvsl=findViewById(R.id.slot9_detail_tvsl);
        //get data from prev intent
        Intent intent=getIntent();
        //convert to product object

        productSL8 = intent.getParcelableExtra("PRODUCT");
        if(productSL8!=null){
            Picasso.get().load(productSL8.getSearch_image()).into(imageView);
            tvstyleid.setText(productSL8.getStyleid());
            tvbrands_filter_facet.setText(productSL8.getBrands_filter_facet());
            tvprice.setText(productSL8.getPrice());
            tvproduct_additional_info.setText(productSL8.getProduct_additional_info());
            tvsl.setText("So luonng: "+1);
        }


    }
}