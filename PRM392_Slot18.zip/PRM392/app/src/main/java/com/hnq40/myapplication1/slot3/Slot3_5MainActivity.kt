package com.hnq40.myapplication1.slot3

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.hnq40.myapplication1.R

class Slot3_5MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot35_main)
        var lv = findViewById<ListView>(R.id.slot3_5Lv)
        val data = listOf("a","b","c","d","e","f","g")
        val adap = ArrayAdapter(this,android.R.layout.simple_list_item_1,data)
        lv.adapter=adap
    }
}