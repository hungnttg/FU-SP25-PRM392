package com.hnq40.myapplication1.slot6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot6DAOSanPham {
    private Slot6Helper dbhelper;
    private Context context;
    private SQLiteDatabase db;

    public Slot6DAOSanPham(Context context) {
        this.context = context;
        dbhelper=new Slot6Helper(context);//goi phuong thuc tao CSDL, bang du lieu
        db=dbhelper.getWritableDatabase();//cho phep du lieu
    }
    //insert
    public int insertSP(Slot6SanPham p){
        ContentValues values=new ContentValues();//doi tuong chua du lieu
        values.put("masp",p.getMasp());//dua du lieu vao doi tuong chua
        values.put("tensp",p.getTensp());
        values.put("sl",p.getSl());
        if(db.insert("sanpham",null,values)<0){
            return -1;//that bai
        }
        return 1;//thanh cong
    }
    //update
    public int updateSP(Slot6SanPham p){
        ContentValues values=new ContentValues();//doi tuong chua du lieu
        values.put("tensp",p.getTensp());
        values.put("sl",p.getSl());
        if(db.update("sanpham",values,"masp=?",
                new String[]{p.getMasp()})<0){
            return -1;//that bai
        }
        return 1;//thanh cong
    }
    //delete
    public int deleteSP(String masp){
        if(db.delete("sanpham","masp=?",
                new String[]{masp})<0){
            return -1;//that bai
        }
        return 1;//thanh cong
    }
    //getAll
    public List<Slot6SanPham> getAllData(){
        List<Slot6SanPham> list=new ArrayList<>();//list chua du lieu
        //tao con tro doc du lieu
        Cursor c=db.query("sanpham",null,null,null,
                null,null,null);
        c.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (!c.isAfterLast())//khong phai ban ghi cuoi cung thi van doc
        {
            Slot6SanPham p=new Slot6SanPham();//tao doi tuong chua du liei
            p.setMasp(c.getString(0));
            p.setTensp(c.getString(1));
            p.setSl(c.getString(2));
            list.add(p);//them doi tuong vao list
            c.moveToNext();//di chuyen sang ban ghi tiep theo
        }
        c.close();
        return list;
    }
}
