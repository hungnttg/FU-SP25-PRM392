package com.hnq40.myapplication1.slot8;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Slot8MainActivity extends AppCompatActivity {
    Context context=this;
    List<ProductSL8> list= new ArrayList<>();
    Slot8Adapter adapter;
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot8_main);
        listView=findViewById(R.id.slot8_listview);
        adapter = new Slot8Adapter(list,this);
        listView.setAdapter(adapter);
        //lop doc du lieu tu internet
        new FetchProductTask().execute();
    }
    private class FetchProductTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder builder = new StringBuilder();//chua du lieu doc duoc
                try {
                    //duong dan
                    URL url=new URL("https://hungnttg.github.io/shopgiay.json");
                    HttpURLConnection connection=(HttpURLConnection) url.openConnection();//mo ket noi
                    //bo dem chua du lieu doc duoc
                    BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    //doc theo dong
                    String line="";
                    while ((line=reader.readLine())!=null){
                        builder.append(line);
                    }
                    reader.close();
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            return builder.toString();
        }
        //tra du lieu ve cho client
        @Override
        protected void onPostExecute(String result) {
            if(result!=null && !result.isEmpty()){//result is not null and blank
                try {
                    JSONObject json = new JSONObject(result);//lay ve 1 doi tuong
                    JSONArray jsonArray = json.getJSONArray("products");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject prdObj = jsonArray.getJSONObject(i);//lay ve tung doi tuong con
                        //lay ve tung truowng
                        String search_image=prdObj.getString("search_image");
                        String styleid=prdObj.getString("styleid");
                        String brands_filter_facet=prdObj.getString("brands_filter_facet");
                        String price=prdObj.getString("price");
                        String product_additional_info=prdObj.getString("product_additional_info");
                        //create an object with some field
                        ProductSL8 p=new ProductSL8(search_image,styleid,brands_filter_facet,price,product_additional_info);
                        //add the object to list
                        list.add(p);
                    }
                    adapter.notifyDataSetChanged();//reload list
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}