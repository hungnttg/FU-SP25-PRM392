package com.hnq40.myapplication1.slot13.insert;

public class SvrResponseSelect {//GET
    private Prd[] products;
    private String message;

    public Prd[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
