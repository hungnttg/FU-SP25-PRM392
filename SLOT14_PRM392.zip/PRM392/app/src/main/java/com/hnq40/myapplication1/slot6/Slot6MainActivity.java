package com.hnq40.myapplication1.slot6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot6MainActivity extends AppCompatActivity {
    ListView listView;
    Button btnInsert,btnUpdate,btnDelete,btnSelect;
    EditText txtMa,txtTen,txtSL;
    Context context=this;
    Slot6DAOSanPham dao;
    Slot6Adapter adapter;
    List<Slot6SanPham> list=new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot6_main);
        listView=findViewById(R.id.slot6_listview);
        btnInsert=findViewById(R.id.slot6_btnInsert);
        btnUpdate=findViewById(R.id.slot6_btnUpdate);
        btnDelete=findViewById(R.id.slot6_btnDelete);
        btnSelect=findViewById(R.id.slot6_btnSelect);
        txtMa=findViewById(R.id.slot6_txtMasp);
        txtTen=findViewById(R.id.slot6_txtTensp);
        txtSL=findViewById(R.id.slot6_txtSl);
        dao=new Slot6DAOSanPham(context);
        list=dao.getAllData();
        adapter=new Slot6Adapter(list,this);
        listView.setAdapter(adapter);
        btnInsert.setOnClickListener(v->{
            Slot6SanPham p=new Slot6SanPham();
            p.setMasp(txtMa.getText().toString());
            p.setTensp(txtTen.getText().toString());
            p.setSl(txtSL.getText().toString());
            int kq=dao.insertSP(p);
            if(kq==-1){
                Toast.makeText(getApplicationContext(),"Insert that bai",Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(getApplicationContext(),"Insert thanh cong",Toast.LENGTH_LONG).show();
            }
            list.clear();
            list=dao.getAllData();
            adapter=new Slot6Adapter(list,this);
            listView.setAdapter(adapter);
        });
        btnSelect.setOnClickListener(v->{
            list.clear();
            list=dao.getAllData();
            adapter.notifyDataSetChanged();
        });
        btnUpdate.setOnClickListener(v->{
            Slot6SanPham p=new Slot6SanPham();
            p.setMasp(txtMa.getText().toString());
            p.setTensp(txtTen.getText().toString());
            p.setSl(txtSL.getText().toString());
            int kq=dao.updateSP(p);
            if(kq==-1){
                Toast.makeText(getApplicationContext(),"Update that bai",Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(getApplicationContext(),"Update thanh cong",Toast.LENGTH_LONG).show();
            }
            list.clear();
            list=dao.getAllData();
            adapter=new Slot6Adapter(list,this);
            listView.setAdapter(adapter);
        });

    }
}