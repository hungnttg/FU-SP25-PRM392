package com.hnq40.myapplication1.slot4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Slot4_2MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot41_main);
        listView = findViewById(R.id.slot4_1Lv);
        //b1 - Tao danh sach
        List<HashMap<String,Object>> list = new ArrayList<>();
        //b2- tao cac doi tuong va add vao danh sach
        HashMap<String,Object> hm = new HashMap<>();
        hm.put("name","NVA"); hm.put("age",18);hm.put("pic",R.drawable.apple);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("name","NVB"); hm.put("age",22);hm.put("pic",R.drawable.chrome);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("name","Nguyen van C"); hm.put("age",19);hm.put("pic",R.drawable.facebook);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("name","Nguyen D"); hm.put("age",31);hm.put("pic",R.drawable.blogger);
        list.add(hm);
        //from
        String[] from ={"name","age","pic"};
        //to
        int[] to = {R.id.slot4_1_itemview_tvName,R.id.slot4_1_itemview_tvAge,R.id.slot4_1_itemview_img};
        //
        SimpleAdapter simpleAdapter=new SimpleAdapter(this,list,R.layout.slot4_1_itemview,from,to);
        listView.setAdapter(simpleAdapter);
    }
}