package com.hnq40.myapplication1.slot4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;

public class Slot4_1Adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Slot4_1SinhVien> list;

    public Slot4_1Adapter(Context context, ArrayList<Slot4_1SinhVien> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view (neu chua co -> tao; neu co roi => lay view cu)
    //gan du lieu cho view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Slot4_1ViewHolder viewHolder;
        if(convertView==null){//neu chua co view -> tao view moi
            //tao view moi
            convertView= LayoutInflater.from(context)
                    .inflate(R.layout.slot4_1_itemview,parent,false);
            //anh xa cac thanh phan
            viewHolder = new Slot4_1ViewHolder();
            viewHolder.img = convertView.findViewById(R.id.slot4_1_itemview_img);
            viewHolder.tvName=convertView.findViewById(R.id.slot4_1_itemview_tvName);
            viewHolder.tvAge = convertView.findViewById(R.id.slot4_1_itemview_tvAge);
            //tao 1 template de lan sau su dung
            convertView.setTag(viewHolder);
        }
        else { //neu da co view -> lay view cu
            viewHolder=(Slot4_1ViewHolder) convertView.getTag();
        }
        //gan du lieu
        Slot4_1SinhVien sv = list.get(position);
        viewHolder.img.setImageResource(sv.getPic());
        viewHolder.tvName.setText(sv.getName());
        viewHolder.tvAge.setText(String.valueOf(sv.getAge()));

        return convertView;
    }

    static class Slot4_1ViewHolder {
        ImageView img;
        TextView tvName,tvAge;
    }
}
