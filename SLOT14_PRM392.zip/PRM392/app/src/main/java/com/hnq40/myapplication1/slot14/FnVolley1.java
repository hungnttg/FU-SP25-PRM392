package com.hnq40.myapplication1.slot14;

import android.content.Context;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FnVolley1 {
    //doc du lieu tu trang google.com
    public void getStringVolley(Context context, TextView textView){
        //1. tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. url:
        String url="https://www.google.com/";
        //3. truyen tham so
        StringRequest stringRequest = new StringRequest(
                Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("KQ: "+response.substring(0,1000));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        }
        );
        //4. thuc thi request
        queue.add(stringRequest);
    }
    String strKQ="";
    public void getJSON_Array_of_Objects(Context context,TextView textView){
        strKQ="";
        //1. tao request
        RequestQueue queue=Volley.newRequestQueue(context);
        //2. url:
        String url="https://hungnttg.github.io/array_json_new.json";
        //3. truyen tham so
        JsonArrayRequest request = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for(int i=0;i<response.length();i++){
                    try {
                        JSONObject person = response.getJSONObject(i);
                        String id=person.getString("id");
                        String name=person.getString("name");
                        String email = person.getString("email");
                        strKQ += "Id: "+ id+"\n";
                        strKQ += "Name: "+ name+"\n";
                        strKQ += "Email: "+ email+"\n";
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                textView.setText(strKQ);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //4. thuc thi request
        queue.add(request);
    }
}
