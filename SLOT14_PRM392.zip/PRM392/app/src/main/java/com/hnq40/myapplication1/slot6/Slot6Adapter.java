package com.hnq40.myapplication1.slot6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot6Adapter extends BaseAdapter {
    private List<Slot6SanPham> list;
    private Context context;

    public Slot6Adapter(List<Slot6SanPham> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Slot6ViewHolder holder;
        if(convertView==null){
            //tao layout blank
            convertView= LayoutInflater.from(context)
                    .inflate(R.layout.slot6_item_view,parent,false);
            //anh xa thanh phan
            holder=new Slot6ViewHolder();
            holder.img=convertView.findViewById(R.id.slot6_itemview_img);
            holder.tvMa=convertView.findViewById(R.id.slot6_itemview_tvMasp);
            holder.tvTen=convertView.findViewById(R.id.slot6_itemview_tvTensp);
            holder.tvSl=convertView.findViewById(R.id.slot6_itemview_tvSl);
            holder.btnSua=convertView.findViewById(R.id.slot6_itemview_btnSua);
            holder.btnSua.setOnClickListener(v->{
                //bai tap
                //c1 - dung intent: truyen du lieu sang activity moi
                //c2 - dung dialog: (hoc sau)

            });
            holder.btnXoa=convertView.findViewById(R.id.slot6_itemview_btnXoa);
            holder.btnXoa.setOnClickListener(v->{
                //xoa trong db
                Slot6DAOSanPham dao = new Slot6DAOSanPham(context);
                dao.deleteSP(list.get(position).getMasp());
                //xoa trong list
                list.remove(position);
                //cap nhat len list
                notifyDataSetChanged();

            });
            //tao 1 template de lan sau su dung
            convertView.setTag(holder);
        }
        else {//neu co view -> su dung view cu
            holder=(Slot6ViewHolder) convertView.getTag();
        }
        //truyen du lieu
        Slot6SanPham p=list.get(position);
        if(p!=null){
            holder.img.setImageResource(R.drawable.android);
            holder.tvMa.setText(p.getMasp());
            holder.tvTen.setText(p.getTensp());
            holder.tvSl.setText(p.getSl());
        }
        return convertView;
    }
    static class Slot6ViewHolder{
        ImageView img;
        TextView tvMa,tvTen,tvSl;
        Button btnSua,btnXoa;
    }
}
