package com.hnq40.myapplication1.slot14;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

public class Slot14_1MainActivity extends AppCompatActivity {
    Button btnSelect;
    TextView tvKQ;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot13_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnSelect=findViewById(R.id.slot13_btnSelect);
        tvKQ=findViewById(R.id.slot13_tvKQ);
        btnSelect.setOnClickListener(v->{
            FnVolley1 fnVolley1 = new FnVolley1();
            //fnVolley1.getStringVolley(context,tvKQ);
            fnVolley1.getJSON_Array_of_Objects(context,tvKQ);
        });
    }
}