<?php
function connectDB(){
    return new mysqli('localhost','root','','a8');  
}
function addSP($ma,$ten,$dg,$sl){
    $conn = connectDB();
    $i = $conn->query('INSERT INTO SanPham VALUES ("'.$ma.'","'.$ten.'","'.$dg.'","'.$sl.'")');
    return $i;
}
function displaySP(){
    $conn=connectDB();
    $result = $conn->query('SELECT * FROM SanPham');
    return $result;
}
function updateSP($ma,$ten,$dg,$sl){
    $conn = connectDB();
    $i = $conn->query('UPDATE SanPham SET TenSP="'.$ten.'", DonGia="'.$dg.'", 
    SoLuong="'.$sl.'" WHERE MaSP="'.$ma.'"');
    return $i;
}
function deleteSP($ma){
    $conn=connectDB();
    $i=$conn->query('DELETE FROM SanPham WHERE MaSP="'.$ma.'"');
}
?>