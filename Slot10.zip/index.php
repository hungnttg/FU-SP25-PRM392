<!doctype html>
<?php
  session_start();//start session
  require_once('SP.php');//import library
  global $result;//global variable
  $editMaSP = "";//init 
  if(isset($_POST['btnEdit'])){//if btnEdit button is clicked
    $editMaSP = $_POST['editMaSP'];//gan du lieu cho editMaSP tu form chuyen sang qua POST
  }
  $deleteMaSP="";
  if(isset($_POST['btnDelete'])){//if btnEdit button is clicked
    $deleteMaSP = $_POST['deleteMaSP'];//gan du lieu cho editMaSP tu form chuyen sang qua POST
  }
?>
<html lang="en">
  <head>
    <title>Product Management</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      <div class="jumbotron">
        <h1 class="display-3">Product Management</h1>
        <hr class="my-2">      
      </div>
      <!-- Nav tabs -->
      <ul class="nav nav-tabs" id="navId">
        <li class="nav-item">
          <a href="#tab1Id" class="nav-link active">Active</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#tab2Id">Action</a>
            <a class="dropdown-item" href="#tab3Id">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#tab4Id">Action</a>
          </div>
        </li>
        <li class="nav-item">
          <a href="index2.php" class="nav-link">Another link</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link disabled">Disabled</a>
        </li>
      </ul>
      
      <!-- Tab panes -->
      <div class="tab-content">
        <div class="tab-pane fade show active" id="tab1Id" role="tabpanel"></div>
        <div class="tab-pane fade" id="tab2Id" role="tabpanel"></div>
        <div class="tab-pane fade" id="tab3Id" role="tabpanel"></div>
        <div class="tab-pane fade" id="tab4Id" role="tabpanel"></div>
        <div class="tab-pane fade" id="tab5Id" role="tabpanel"></div>
      </div>
      
      <script>
        $('#navId a').click(e => {
          e.preventDefault();
          $(this).tab('show');
        });
      </script>
      <div class="card">
     
        <div class="card-body">
            <h4 class="card-title">Add new Products</h4>
            <!-- controls -->
             <form action="" method="post">
                <div class="form-group">
                  <label for="">MaSP</label>
                  <input type="text"
                    class="form-control" name="txtMaSP" id="txtMaSP" value="<?php echo $editMaSP; ?>" >
                </div>
                <div class="form-group">
                    <label for="">TenSP</label>
                    <input type="text"
                      class="form-control" name="txtTenSP" id="txtTenSP" >
                </div>
                <div class="form-group">
                    <label for="">DonGia</label>
                    <input type="text"
                      class="form-control" name="txtDonGia" id="txtDonGia" >
                </div>
                <div class="form-group">
                    <label for="">SoLuong</label>
                    <input type="text"
                      class="form-control" name="txtSoLuong" id="txtSpLuong" >
                </div>
                <button type="submit" name="btnAdd" class="btn btn-warning">Add</button>
                <button type="submit" name="btnDisplay" class="btn btn-primary">Display</button>
                <button type="submit" name="btnUpdate" class="btn btn-danger">Update</button>
             </form>
             <!-- end controls -->
        </div>
      </div>
      <div class="card">

        <div class="card-body">
            <h4 class="card-title">Products List</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>MaSP</th>
                        <th>TenSP</th>
                        <th>DonGia</th>
                        <th>SoLuong</th>
                        <th>Action</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                  <?php
                      if(isset($_POST['btnDisplay'])){//neu click button display
                          $result = displaySP();//read data from db
                          while($row = $result->fetch_assoc())//read by line
                          {
                            echo '<tr>'; 
                            echo '<td>'.$row['MaSP'].'</td>';
                            echo '<td>'.$row['TenSP'].'</td>';
                            echo '<td>'.$row['DonGia'].'</td>';
                            echo '<td>'.$row['SoLuong'].'</td>';
                            echo '<td>
                                    <form action="" method="post">
                                        <input type="hidden"
                                          class="form-control" name="editMaSP" value="'.$row['MaSP'].'">
                                        <button type="submit" name="btnEdit" class="btn btn-primary">Edit</button>              
                                    </form>
                                  </td>';
                            echo '<td>
                                    <form action="" method="post">
                                        <input type="hidden"
                                          class="form-control" name="deleteMaSP" value="'.$row['MaSP'].'">
                                        <button type="submit" name="btnDelete" class="btn btn-primary">Delete</button>              
                                    </form>
                                  </td>';
                            echo '</tr>';
                          }
                      }
                  ?>              
                </tbody>
            </table>    
        </div>
      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <?php
      if(isset($_POST['btnAdd']))//neu btn them duoc click
      {
        //get data from user
        $MaSP = $_POST['txtMaSP'];
        $TenSP = $_POST['txtTenSP'];
        $DonGia = $_POST['txtDonGia'];
        $SoLuong = $_POST['txtSoLuong'];
        //goi ham them du lieu
        $i = addSP($MaSP,$TenSP,$DonGia,$SoLuong);
        if($i<0){
          echo "Them that bai";
        }
        else {
          echo "Them thanh cong";
        }
      }
      if(isset($_POST['btnUpdate'])){//neu button update duoc click
          //get data from user
          $MaSP = $_POST['txtMaSP'];
          $TenSP = $_POST['txtTenSP'];
          $DonGia = $_POST['txtDonGia'];
          $SoLuong = $_POST['txtSoLuong'];
          //goi ham them du lieu
          $i = updateSP($MaSP,$TenSP,$DonGia,$SoLuong);
          if($i<0){
            echo "Update that bai";
          }
          else {
            echo "Update thanh cong";
          }
      }
      if(isset($_POST['btnEdit'])){//khi button edit duoc click
        $MaSP = $_POST['txtMaSP'];
        echo "Edit product with MaSP: $MaSP";
      }
      if(isset($_POST['btnDelete'])){//neu button delete duoc click
        $i = deleteSP($deleteMaSP);
        if($i<0){
          echo "Delete that bai";
        }
        else {
          echo "Delete thanh cong";
        }
      }
    ?>
  </body>
</html>