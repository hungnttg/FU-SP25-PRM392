package com.hnq40.myapplication1.slot4

class Slot4_1Student {
    var name: String? = null
    var age: String? = null
    var pic: Int = 0

    constructor(name: String?, age: String?, pic: Int) {
        this.name = name
        this.age = age
        this.pic = pic
    }

    constructor()

}