package com.hnq40.myapplication1.slot2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

public class Slot2_1MainActivity extends AppCompatActivity {
    //khai bao cac id
    EditText txt1,txt2;
    Button btn1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot21_main);
        //anh xa cac id
        txt1=findViewById(R.id.slot2_1Txt1);
        txt2=findViewById(R.id.slot2_1Txt2);
        btn1=findViewById(R.id.slot2_1Btn1);
        tv1=findViewById(R.id.slot2_1Tv1);
        //xu ly su kien
        btn1.setOnClickListener(v->{
            //lay ve du lieu nguoi dung nhap va chuyen sang kieu int
            int a = Integer.parseInt(txt1.getText().toString());
            int b = Integer.parseInt(txt2.getText().toString());
            //int tong = a+b;
            //hien thi du lieu cho nguoi dung
            //tv1.setText(String.valueOf(tong));
            //---------------
            //Tao intent de van chuyen du lieu
            Intent intent = new Intent(this,Slot2_2MainActivity.class);
            //dua du lieu vao intent
            intent.putExtra("soA",a);
            intent.putExtra("soB",b);
            //thuc hien van chuyen
            startActivity(intent);
        });
    }
}