package com.hnq40.myapplication1.slot4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot4_1MainActivity extends AppCompatActivity {
    ListView listView;
    Slot4_1Adapter adapter;
    List<Slot4_1SinhVien> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot41_main);
        listView=findViewById(R.id.slot4_1Lv);
        list.add(new Slot4_1SinhVien("Nguyen Van A","18",R.drawable.android));
        list.add(new Slot4_1SinhVien("Tran Van B","19",R.drawable.apple));
        list.add(new Slot4_1SinhVien("VU Van C","21",R.drawable.chrome));
        list.add(new Slot4_1SinhVien("Nguyen Thi D","17",R.drawable.blogger));

        adapter = new Slot4_1Adapter(this,list);
        listView.setAdapter(adapter);
    }
}