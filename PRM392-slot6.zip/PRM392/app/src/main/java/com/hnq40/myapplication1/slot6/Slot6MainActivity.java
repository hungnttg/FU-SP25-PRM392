package com.hnq40.myapplication1.slot6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot6MainActivity extends AppCompatActivity {
    ListView listView;
    Button btnInsert,btnUpdate,btnLoad,btnDel;
    EditText txtMa,txtTen,txtSl;
    Context context=this;
    Slot6SanPhamDAO dao;
    List<Slot6SanPham> list=new ArrayList<>();
    Slot6Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot6_main);
        listView=findViewById(R.id.slot6Lv);
        btnInsert=findViewById(R.id.slot6_btnInsert);
        btnDel=findViewById(R.id.slot6_btnDelete);
        btnLoad=findViewById(R.id.slot6_btnLoad);
        btnUpdate = findViewById(R.id.slot6_btnEdit);
        txtMa = findViewById(R.id.slot6_txtMasp);
        txtTen=findViewById(R.id.slot6_txtTensp);
        txtSl=findViewById(R.id.slot6_txtSl);
        dao=new Slot6SanPhamDAO(context);//thuc thi tao db va bang du lieu
        list=dao.getAllSanPham();
        adapter=new Slot6Adapter(list,context);
        listView.setAdapter(adapter);
        btnLoad.setOnClickListener(v->{
            list.clear();
            list=dao.getAllSanPham();
            adapter=new Slot6Adapter(list,context);
            listView.setAdapter(adapter);
        });
        btnInsert.setOnClickListener(v->{
            Slot6SanPham p = new Slot6SanPham();
            p.setMasp(txtMa.getText().toString());
            p.setTensp(txtTen.getText().toString());
            p.setSl(Integer.parseInt(txtSl.getText().toString()));
            int kq=dao.insertSP(p);
            if(kq==1){
                Toast.makeText(getApplicationContext(),"Insert thanh cong",Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Insert that bai",Toast.LENGTH_LONG).show();
            }
        });
        btnDel.setOnClickListener(v->{
            int kq = dao.deleteSP(txtMa.getText().toString());
            if(kq==1){
                Toast.makeText(getApplicationContext(),"Xoa thanh cong",Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Xoa that bai",Toast.LENGTH_LONG).show();
            }
        });
        btnUpdate.setOnClickListener(v->{
            Slot6SanPham p = new Slot6SanPham();
            p.setMasp(txtMa.getText().toString());
            p.setTensp(txtTen.getText().toString());
            p.setSl(Integer.parseInt(txtSl.getText().toString()));
            int kq=dao.updateSP(p);
            if(kq==1){
                Toast.makeText(getApplicationContext(),"Sua thanh cong",Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Sua that bai",Toast.LENGTH_LONG).show();
            }
        });
    }
}