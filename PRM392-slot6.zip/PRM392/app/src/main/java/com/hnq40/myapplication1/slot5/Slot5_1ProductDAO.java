package com.hnq40.myapplication1.slot5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot5_1ProductDAO {
    private Slot5_1SqliteHelper helper;
    private SQLiteDatabase db;
    private Context context;
    //goi ham tao database va bang du lieu
    public Slot5_1ProductDAO(Context context) {
        this.context = context;
        helper=new Slot5_1SqliteHelper(context);
        db=helper.getWritableDatabase();
    }
    //insert
    public int insertProduct(Slot5_1Product p){
        ContentValues values = new ContentValues();//data for insert
        //put data
        values.put("id",p.getId());
        values.put("name",p.getName());
        values.put("price",p.getPrice());
        values.put("image",p.getImage());
        //execute insert
        if(db.insert("Product",null,values)<0){
            return -1;//not success
        }
        return 1;//success
    }
    //get all data
    public List<Slot5_1Product> getAllData(){
        List<Slot5_1Product> ls = new ArrayList<>();
        //cursor for read data
        Cursor c=db.query("Product",null,null,null,null,null,null);
        c.moveToFirst();
        while (c.isAfterLast()==false){//neu khong phai la ban ghi cuoi cung => tiep tuc doc
            Slot5_1Product p = new Slot5_1Product();
            p.setId(c.getString(0));
            p.setName(c.getString(1));
            p.setPrice(c.getDouble(2));
            ls.add(p);
            c.moveToNext();
        }
        c.close();
        return ls;
    }
}
