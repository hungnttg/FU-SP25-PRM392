package com.hnq40.myapplication1.slot4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Slot4_3MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot41_main);
        listView = findViewById(R.id.slot4_1Lv);
        //B1 - tao itemView (da tao)
        //B2 - tao dataSource
        List<Map<String, Object>> list = new ArrayList<>();
        HashMap<String,Object> has = new HashMap<>();
        has.put("name","Hung");
        has.put("age","30");
        has.put("pic",R.drawable.android);
        list.add(has);

        has = new HashMap<>();
        has.put("name","Hung2");
        has.put("age","27");
        has.put("pic",R.drawable.apple);
        list.add(has);

        has = new HashMap<>();
        has.put("name","Hung3");
        has.put("age","20");
        has.put("pic",R.drawable.firefox);
        list.add(has);

        has = new HashMap<>();
        has.put("name","Hung4");
        has.put("age","25");
        has.put("pic",R.drawable.chrome);
        list.add(has);
        //b3- anh xa nguon du lieu
        String[] from = {"name","age","pic"};
        int[] to = {R.id.slot4_1_ItemView_name,R.id.slot4_1_ItemView_age,R.id.slot4_1ItemView_img};
        //b4. tao adapter
        SimpleAdapter adapter = new SimpleAdapter(this,list,R.layout.slot4_1_itemview,from,to);
        //b5. dua du lieu len listview
        listView.setAdapter(adapter);

    }
}