package com.hnq40.myapplication1.slot4;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot4_1Adapter extends BaseAdapter {
    private Context context;
    private List<Slot4_1SinhVien> list;

    public Slot4_1Adapter(Context context, List<Slot4_1SinhVien> list) {
        this.context = context;
        this.list = list;
    }
    //lay ve tong cac item
    @Override
    public int getCount() {
        return list.size();
    }
    //lay ve 1 item
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    //lay ve id cua item
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao layout
    //dien du lieu cho layout
    @SuppressLint("WrongViewCast")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //create view
        Slot4_1ViewHolder holder;
        if(convertView==null){//if not exist view -> create a new view
            //create a blank view
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.slot4_1_itemview,parent,false);
            //refer to the view holder
            holder = new Slot4_1ViewHolder();
            holder.img_pic = convertView.findViewById(R.id.slot4_1ItemView_img);
            holder.tvName = convertView.findViewById(R.id.slot4_1_ItemView_name);
            holder.tvAge=convertView.findViewById(R.id.slot4_1_ItemView_age);
            //create a template for later
            convertView.setTag(holder);
        }
        else {//exist view -> use old view
            holder = (Slot4_1ViewHolder) convertView.getTag();
        }
        //set data for view
        Slot4_1SinhVien sv = list.get(position);
        holder.img_pic.setImageResource(sv.getPic());
        holder.tvName.setText(sv.getName());
        holder.tvAge.setText(sv.getAge());
        return convertView;
    }
    //create a class for refer to the item view
    static class Slot4_1ViewHolder{
        ImageView img_pic;
        TextView tvName,tvAge;
    }
}
