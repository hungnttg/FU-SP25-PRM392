package com.hnq40.myapplication1.slot8;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot9CartActivity extends AppCompatActivity {
    ListView listView;
    Slot9CartItemAdapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot9_cart);
        listView = findViewById(R.id.slot9_cartActivity_listview);
        //init list of cart and adapter
        Slot9CartManager cartManager=Slot9CartManager.getInstance();//only one
        List<ProductSL8> cartItems = cartManager.getCartItems();//cart item for cartManager
        //init adapter
        adapter = new Slot9CartItemAdapter(this,cartItems);
        listView.setAdapter(adapter);
    }
}