package com.hnq40.myapplication1.slot8;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Slot8Adapter extends BaseAdapter {
    private List<ProductSL8> list;
    private Context context;

    public Slot8Adapter(List<ProductSL8> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Slot8ViewHolder holder;
        if(convertView==null){
            //tao view blank
            convertView= LayoutInflater.from(context)
                    .inflate(R.layout.slot8_itemview,parent,false);
            //anh xa tung thanh phan
            holder=new Slot8ViewHolder();
            holder.img=convertView.findViewById(R.id.slot8_itemview_img);
            holder.tvsl=convertView.findViewById(R.id.slot8_itemview_tvsl);
            holder.tvprice=convertView.findViewById(R.id.slot8_itemview_tvprice);
            holder.tvstyleid=convertView.findViewById(R.id.slot8_itemview_tvstyleid);
            holder.tvbrands_filter_facet=convertView.findViewById(R.id.slot8_itemview_tvbrands_filter_facet);
            //tao template
            convertView.setTag(holder);
        }
        else {
            holder=(Slot8ViewHolder) convertView.getTag();//lay template ra su dung
        }
        //set du lieu
        ProductSL8 p=list.get(position);
        if(p!=null){
            holder.tvbrands_filter_facet.setText(p.getBrands_filter_facet());
            holder.tvprice.setText(p.getPrice());
            holder.tvstyleid.setText(p.getStyleid());
            holder.tvsl.setText("1");
            Picasso.get().load(p.getSearch_image()).into(holder.img);//doc anh tu mang
        }
        //---event---
        convertView.setOnClickListener(v->{
            ProductSL8 productSL8 = list.get(position);
            Intent intent = new Intent(context,Slot9DetailActivity.class);
            intent.putExtra("PRODUCT",productSL8);
            context.startActivity(intent);
        });
        //--end event
        return convertView;
    }
    static class Slot8ViewHolder{
        ImageView img;
        TextView tvstyleid, tvbrands_filter_facet,tvsl,tvprice;
    }
}
