package com.hnq40.myapplication1.slot8;

import java.util.ArrayList;
import java.util.List;

public class Slot9CartManager {
    private static Slot9CartManager instance;
    private List<ProductSL8> cartItems;
    Slot9CartManager(){
        cartItems = new ArrayList<>();
    }
    public static synchronized Slot9CartManager getInstance(){
        if(instance==null){
            instance=new Slot9CartManager();
        }
        return instance;
    }
    public void addProductToCart(ProductSL8 productSL8){
        cartItems.add(productSL8);
    }
    public List<ProductSL8> getCartItems(){
        return cartItems;
    }
}
