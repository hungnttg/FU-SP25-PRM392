package com.hnq40.myapplication1.slot8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot9CartItemAdapter extends ArrayAdapter<ProductSL8> {
   private Context context;
    public Slot9CartItemAdapter(Context context, List<ProductSL8> products) {
        super(context, 0, products);
        this.context = context;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem==null){
            listItem= LayoutInflater.from(context).inflate(R.layout.slot9_cart_item,parent,false);
        }
        //get current product
        ProductSL8 currentProduct = getItem(position);
        //display info of product in cart
        TextView productBrand = listItem.findViewById(R.id.slot9_cartitem_tvbrand);
        productBrand.setText(currentProduct.getBrands_filter_facet());
        TextView productId = listItem.findViewById(R.id.slot9_cartitem_tvId);
        productId.setText(currentProduct.getStyleid());
        TextView productQuantity = listItem.findViewById(R.id.slot9_cartitem_tvQuantity);
        productQuantity.setText("Quantity: "+1);
        return listItem;
    }
}
