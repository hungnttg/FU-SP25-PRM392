package com.hnq40.myapplication1.slot4

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.hnq40.myapplication1.R

class Slot4_1CustomAdapter(private val list: ArrayList<Slot4_1Student>,
    private val context: Context): BaseAdapter() {
    override fun getCount(): Int {
        return list.size
    }

    override fun getItem(position: Int): Any {
        return list[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        val holder: Slot4_1ViewHolderKL
        var convertView = convertView
        if(convertView==null){
            holder= Slot4_1ViewHolderKL()
            convertView=LayoutInflater.from(context)
                .inflate(R.layout.slot4_1_itemview,null)
            holder.img_pic=convertView.findViewById(R.id.slot4_1ItemView_img)
            holder.tvName=convertView.findViewById(R.id.slot4_1_ItemView_name)
            holder.tvAge=convertView.findViewById(R.id.slot4_1_ItemView_age)
            convertView.tag = holder
        }
        else {
            holder = convertView.tag as Slot4_1ViewHolderKL
        }
        holder.img_pic!!.setImageResource(list[position].pic)
        holder.tvName!!.setText(list[position].name)
        holder.tvAge!!.setText(list[position].age)
        return convertView

    }
    internal class Slot4_1ViewHolderKL {
        var img_pic: ImageView? = null
        var tvName: TextView? =null
        var tvAge : TextView? = null
    }
}