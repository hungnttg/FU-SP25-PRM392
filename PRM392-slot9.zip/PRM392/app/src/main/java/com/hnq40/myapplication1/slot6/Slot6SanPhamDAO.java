package com.hnq40.myapplication1.slot6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot6SanPhamDAO {
    private Slot6DbHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;

    public Slot6SanPhamDAO(Context context) {
        this.context = context;
        dbHelper = new Slot6DbHelper(context);
        db=dbHelper.getWritableDatabase();
    }
    //them
    public int insertSP(Slot6SanPham p){
        ContentValues values = new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("sl",String.valueOf(p.getSl()));
        if(db.insert("sanpham",null,values)<0){
            return -1;
        }
        return 1;
    }
    //sua
    public int updateSP(Slot6SanPham p){
        ContentValues values=new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("sl",String.valueOf(p.getSl()));
        if(db.update("sanpham",values,"masp=?",new String[]{p.getMasp()})<0){
            return -1;
        }
        return 1;
    }
    //xoa
    public int deleteSP(String masp){
        if(db.delete("sanpham","masp=?",new String[]{masp})<0){
            return -1;
        }
        return 1;
    }
    //hien thi
    public List<Slot6SanPham> getAllSanPham(){
        List<Slot6SanPham> ls = new ArrayList<>();
        Cursor c = db.query("sanpham",null,null,null,null,
                null,null);
        c.moveToFirst();
        while (!c.isAfterLast()){
            Slot6SanPham p=new Slot6SanPham();
            p.setMasp(c.getString(0));
            p.setTensp(c.getString(1));
            p.setSl(c.getInt(2));
            ls.add(p);
            c.moveToNext();
        }
        c.close();
        return ls;
    }
}
