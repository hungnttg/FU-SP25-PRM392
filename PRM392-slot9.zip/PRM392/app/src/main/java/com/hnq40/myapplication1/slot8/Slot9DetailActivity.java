package com.hnq40.myapplication1.slot8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;
import com.squareup.picasso.Picasso;

public class Slot9DetailActivity extends AppCompatActivity {
    ImageView imageView;
    TextView tvstyleid, tvbrands_filter_facet,tvprice,tvproduct_additional_info;
    Button btnAddToCart;
    private Slot9CartManager cartManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot9_detail);
        cartManager=Slot9CartManager.getInstance();//get instance of cart
        imageView = findViewById(R.id.slot9_detail_search_image);
        tvstyleid=findViewById(R.id.slot9_detail_styleid);
        tvbrands_filter_facet=findViewById(R.id.slot9_detail_brands_filter_facet);
        tvprice=findViewById(R.id.slot9_detail_price);
        tvproduct_additional_info=findViewById(R.id.slot9_detail_product_additional_info);
        btnAddToCart=findViewById(R.id.slot9_detail_btnAddToCart);
        //receive data from intent
        Intent intent = getIntent();
        ProductSL8 productSL8 = intent.getParcelableExtra("PRODUCT");//get object
        //display detail of object
        if(productSL8!=null){
            //get image
            Picasso.get().load(productSL8.getSearch_image()).into(imageView);
            //get all text
            tvstyleid.setText("style ID: "+productSL8.getStyleid());
            tvbrands_filter_facet.setText("Brands: "+productSL8.getBrands_filter_facet());
            tvprice.setText("Price: "+productSL8.getPrice());
            tvproduct_additional_info.setText("More Info: "+productSL8.getProduct_additional_info());
        }
        //add product to cart
        btnAddToCart.setOnClickListener(v->{
            Intent intent1 = getIntent();
            ProductSL8 productSL81 = intent1.getParcelableExtra("PRODUCT");
            if(productSL81!=null){
                //add product to cart
                cartManager.addProductToCart(productSL81);
                //open new activity
                Intent cartIntent = new Intent(this,Slot9CartActivity.class);
                startActivity(cartIntent);
            }
        });
    }
}