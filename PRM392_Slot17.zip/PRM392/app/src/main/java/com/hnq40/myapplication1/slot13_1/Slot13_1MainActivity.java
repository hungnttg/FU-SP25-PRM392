package com.hnq40.myapplication1.slot13_1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot13_1MainActivity extends AppCompatActivity {
    EditText txtId,txtName,txtPrice,txtDes;
    Button btnInsert, btnSelect,btnUpdate, btnDelete;
    TextView tvKQ;
    String strKQ="";
    List<Prod> ls=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot13_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txtId=findViewById(R.id.slot13_txtId);
        txtName=findViewById(R.id.slot13_txtName);
        txtPrice=findViewById(R.id.slot13_txtPrice);
        txtDes = findViewById(R.id.slot13_txtDes);
        btnInsert=findViewById(R.id.slot13_btnInsert);
        btnSelect=findViewById(R.id.slot13_btnSelect);
        btnUpdate = findViewById(R.id.slot13_btnUpdate);
        btnDelete = findViewById(R.id.slot13_btnDelete);
        tvKQ = findViewById(R.id.slot13_tvKQ);
        btnSelect.setOnClickListener(v->{
            selectData();
        });
        btnInsert.setOnClickListener(v->{
            insertData();
        });
        btnUpdate.setOnClickListener(v-> {
            updateData();
        });
        btnDelete.setOnClickListener(v->{
            deleteData();
        });
    }
    private void updateData(){
        //b1. create a new retrofit object
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b2. prepare the function
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Call<ResponseInsertPrd> call=interfaceInsertPrd.updatePrd(txtId.getText().toString(),
                txtName.getText().toString(),txtPrice.getText().toString(),txtDes.getText().toString());
        //b3. execute the function
        call.enqueue(new Callback<ResponseInsertPrd>() {
            @Override
            public void onResponse(Call<ResponseInsertPrd> call, Response<ResponseInsertPrd> response) {
                ResponseInsertPrd responseInsertPrd = response.body();
                tvKQ.setText(responseInsertPrd.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseInsertPrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }
    private void deleteData(){
        //b1. create a new retrofit object
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b2. prepare the function
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Call<ResponseInsertPrd> call=interfaceInsertPrd.deletePrd(txtId.getText().toString());
        //b3. execute the function
        call.enqueue(new Callback<ResponseInsertPrd>() {
            @Override
            public void onResponse(Call<ResponseInsertPrd> call, Response<ResponseInsertPrd> response) {
                ResponseInsertPrd responseInsertPrd = response.body();
                tvKQ.setText(responseInsertPrd.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseInsertPrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }
    private void insertData(){
        //b1. tao doi tuong retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. chuan bi ham insert
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Prod p=new Prod();
        p.setId(txtId.getText().toString());
        p.setName(txtName.getText().toString());
        p.setPrice(txtPrice.getText().toString());
        p.setDescription(txtDes.getText().toString());
        Call<ResponseInsertPrd> call= interfaceInsertPrd.insertPrd(p.getId(),p.getName(),p.getPrice(),p.getDescription());
        //3. thuc thi ham
        call.enqueue(new Callback<ResponseInsertPrd>() {
            @Override
            public void onResponse(Call<ResponseInsertPrd> call, Response<ResponseInsertPrd> response) {
                //thanh cong
                ResponseInsertPrd responseInsertPrd=response.body();
                tvKQ.setText(responseInsertPrd.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseInsertPrd> call, Throwable t) {
                //that bai
                tvKQ.setText(t.getMessage());
            }
        });
    }
    private void selectData(){
        strKQ="";
        //b1. create a retrofit object
        Retrofit retrofit= new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0api6/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b2. prepare the select function
        InterfaceSelectPrd interfaceSelectPrd=retrofit.create(InterfaceSelectPrd.class);
        Call<ResponseSelectPrd> call = interfaceSelectPrd.getData();
        //b3. execute function
        call.enqueue(new Callback<ResponseSelectPrd>() {
            @Override
            public void onResponse(Call<ResponseSelectPrd> call, Response<ResponseSelectPrd> response) {
                //success
                ResponseSelectPrd responseSelectPrd=response.body();
                ls= Arrays.asList(responseSelectPrd.getProducts());
                for(Prod p: ls){
                    strKQ += "ID: "+p.getId()+"; Name: "+p.getName()+"; Price: "+p.getPrice()
                            +"; Des: "+p.getDescription()+"\n";
                }
                tvKQ.setText(strKQ);
            }

            @Override
            public void onFailure(Call<ResponseSelectPrd> call, Throwable t) {
                //failed
                tvKQ.setText(t.getMessage());
            }
        });

    }
}