package com.hnq40.myapplication1.slot4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.hnq40.myapplication1.R

class Slot4_3MainActivity : AppCompatActivity() {
    var lv:ListView?=null
    var adapter: Slot4_3Adapter?=null
     lateinit var list: ArrayList<Slot4_3Student>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot41_main)
        lv =findViewById(R.id.slot4_1Lv)
        list= arrayListOf(Slot4_3Student())
        list.add(Slot4_3Student("NVA","18",R.drawable.dell))
        list.add(Slot4_3Student("NVB","20",R.drawable.chrome))
        adapter=Slot4_3Adapter(list,this)
        lv!!.adapter=adapter


    }
}