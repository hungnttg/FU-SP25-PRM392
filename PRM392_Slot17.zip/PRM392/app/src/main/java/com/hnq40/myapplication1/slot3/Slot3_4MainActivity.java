package com.hnq40.myapplication1.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hnq40.myapplication1.R;

public class Slot3_4MainActivity extends AppCompatActivity {
    ListView lv;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot34_main);
        lv = findViewById(R.id.slot3_4Lv);
        getDataToListView();
    }

    private void getDataToListView() {
        //1. tao nguon du lieu
        String[] arr = new String[]{
                "lap trinh android",
                "lap trinh react native",
                "flutter",
                "lap trinh game unity"
        };
        //2. su dung adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Slot3_4MainActivity.this,
                android.R.layout.simple_list_item_1,arr);
        //3. gan adapter vao listview
        lv.setAdapter(adapter);
    }
}