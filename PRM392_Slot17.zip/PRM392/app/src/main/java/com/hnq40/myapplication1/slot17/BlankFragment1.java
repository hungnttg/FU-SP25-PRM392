package com.hnq40.myapplication1.slot17;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hnq40.myapplication1.R;


public class BlankFragment1 extends Fragment {

    Button button;
    EditText editText;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_blank1, container, false);
        //anh xa
        button = view.findViewById(R.id.slot17Fr1Btn1);
        editText = view.findViewById(R.id.slot17Fr1Txt1);
        //xu ly su kien
        button.setOnClickListener(v->{
            Toast.makeText(getContext(),editText.getText(),Toast.LENGTH_LONG).show();
        });
        return view;
    }
}