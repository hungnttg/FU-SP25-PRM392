package com.hnq40.myapplication1.slot5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

import java.util.List;

public class Slot51Adapter extends BaseAdapter {
    private Context context;
    private List<Slot5Product> list;

    public Slot51Adapter(Context context, List<Slot5Product> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //tao view
        Slot51Holder holder;
        if(convertView==null){//khi chua co view
            //tao 1 view blank
            convertView= LayoutInflater.from(context)
                    .inflate(R.layout.slot5_1_itemview,parent,false);
            //anh xa cac control
            holder=new Slot51Holder();
            holder.img=convertView.findViewById(R.id.slot5_1_itemview_img);
            holder.tvId=convertView.findViewById(R.id.slot5_1_itemview_tvId);
            holder.tvName=convertView.findViewById(R.id.slot5_1_itemview_tvName);
            holder.tvPrice=convertView.findViewById(R.id.slot5_1_itemview_tvPrice);
            //tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else { //da co view -> lay view cu ra su dung
            holder=(Slot51Holder)convertView.getTag();
        }
        //gan du lieu cho view
        Slot5Product p = list.get(position);
        if(p!=null){
            holder.img.setImageResource(R.drawable.android);
            holder.tvId.setText(p.getId());
            holder.tvName.setText(p.getName());
            holder.tvPrice.setText(String.valueOf(p.getPrice()));
        }
        return convertView;
    }
    static class Slot51Holder{
        ImageView img;
        TextView tvId,tvName,tvPrice;
    }
}
