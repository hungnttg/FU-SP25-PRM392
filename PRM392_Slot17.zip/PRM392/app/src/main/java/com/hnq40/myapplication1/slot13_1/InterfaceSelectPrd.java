package com.hnq40.myapplication1.slot13_1;

import retrofit2.Call;
import retrofit2.http.GET;

public interface InterfaceSelectPrd {
    @GET("select_prd.php")
    Call<ResponseSelectPrd> getData();
}
