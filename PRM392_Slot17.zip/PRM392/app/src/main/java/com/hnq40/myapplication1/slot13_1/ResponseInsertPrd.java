package com.hnq40.myapplication1.slot13_1;

public class ResponseInsertPrd {//GET
    private String message;

    public String getMessage() {
        return message;
    }
}
