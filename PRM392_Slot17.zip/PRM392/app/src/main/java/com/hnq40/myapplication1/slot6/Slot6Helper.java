package com.hnq40.myapplication1.slot6;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Slot6Helper extends SQLiteOpenHelper {
    public Slot6Helper(Context context) {
        super(context, "TenCSDL", null, 1);//tao csdl
    }

    //tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sanpham (masp text PRIMARY KEY, tensp text, sl text);");
    }
    //nang cap bang du lieu
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS sanpham");
    }
}
