package com.hnq40.myapplication1.slot5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot51DAO {
    private Slot51Helper dbhelper;
    private SQLiteDatabase db;
    private Context context;

    public Slot51DAO(Context context) {
        this.context = context;
        dbhelper = new Slot51Helper(context);//thuc thi tao DB va bang du lieu
        db=dbhelper.getWritableDatabase();//cho phep ghi du lieu
    }
    //insert
    public int insertProd(Slot5Product p){
        ContentValues values=new ContentValues();//tao doi tuong chua du lieu
        //put data
        values.put("id",p.getId());
        values.put("name",p.getName());
        values.put("price",p.getPrice());
        //insert
        if(db.insert("Product",null,values)<0){
            return -1;//insert khong thanh cong
        }
        return 1; //insert thanh cong
    }
    //get all data
    public List<Slot5Product> getAllData(){
        List<Slot5Product> list=new ArrayList<>();
        //cursor read data
        Cursor c=db.query("Product",null,null,null,null,
                null,null);
        c.moveToFirst();//di chuyen ve ban ghi dau tien
        while (c.isAfterLast()==false){//chi doc khi khong phai ban ghi cuoi cung
            Slot5Product p = new Slot5Product();//tao moi 1 doi tuong
            //dua du lieu vao doi tuong
            p.setId(c.getString(0));
            p.setName(c.getString(1));
            p.setPrice(c.getDouble(2));
            list.add(p);//dua doi tuong vao list
            c.moveToNext();//di chuyen sang ban ghi tiep theo
        }
        c.close();//dong con tro
        return list;
    }
}
