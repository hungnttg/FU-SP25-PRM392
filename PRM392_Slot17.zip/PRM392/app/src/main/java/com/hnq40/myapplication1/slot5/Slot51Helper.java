package com.hnq40.myapplication1.slot5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Slot51Helper extends SQLiteOpenHelper {
    //ham tao csdl
    public Slot51Helper(Context context) {
        super(context, "CSDL1", null, 1);
    }
    //tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Product (id text PRIMARY KEY, name text, price real);");
    }
    //xoa bang cu, tao bang moi
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Product");
    }
}
