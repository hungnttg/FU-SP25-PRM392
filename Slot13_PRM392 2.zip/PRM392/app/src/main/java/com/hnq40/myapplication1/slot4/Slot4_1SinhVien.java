package com.hnq40.myapplication1.slot4;

public class Slot4_1SinhVien {
    private String name;
    private int age;
    private int pic;

    public Slot4_1SinhVien() {
    }

    public Slot4_1SinhVien(String name, int age, int pic) {
        this.name = name;
        this.age = age;
        this.pic = pic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getPic() {
        return pic;
    }

    public void setPic(int pic) {
        this.pic = pic;
    }
}
